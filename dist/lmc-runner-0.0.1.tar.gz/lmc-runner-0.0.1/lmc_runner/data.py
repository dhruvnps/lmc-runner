class Data:
    ACC = 0
    PC = 0
    RAM = [[0]] * 100
